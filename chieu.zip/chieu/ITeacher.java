package buoi_5.chieu;

public interface ITeacher {
    double getSalary();
}
